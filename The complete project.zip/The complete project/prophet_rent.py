import numpy as np
import pandas as pd
import matplotlib
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.stats.stattools import durbin_watson
from sklearn.metrics import mean_squared_error, mean_absolute_error
from prophet import Prophet

# Load and preprocess the data
prophe_excel = pd.read_excel("DATE.xlsx")

# Add dummy variables for RegionName
prophe_excel = pd.get_dummies(prophe_excel, columns=["RegionName"], drop_first=True)

print(prophe_excel.head())
# Calculate Monthly Mortgage Payment


# Drop unnecessary columns
prophe_excel = prophe_excel.drop(columns=["SingleFamilyHomeValueIndex"])

# Convert DATE to datetime
prophe_excel['DATE'] = pd.to_datetime(prophe_excel['DATE'])

# Add lagged features
prophe_excel['lag1'] = prophe_excel["SingleFamilyObservedRentIndex"].shift(1)
prophe_excel['lag2'] = prophe_excel["SingleFamilyObservedRentIndex"].shift(2)
prophe_excel['lag3'] = prophe_excel["SingleFamilyObservedRentIndex"].shift(3)
#prophe_excel['lag4'] = prophe_excel["SingleFamilyObservedRentIndex"].shift(4)

# Drop rows with NaN values from lagged features
prophe_excel = prophe_excel.dropna(subset=['lag1','lag2','lag3'])

# Prepare data for Prophet
prophet_data = prophe_excel[['DATE', "SingleFamilyObservedRentIndex", 'lag1','lag2','lag3']].rename(
    columns={'DATE': 'ds', "SingleFamilyObservedRentIndex": 'y'}
)

# Initialize the Prophet model
model = Prophet()
model.add_regressor('lag1')  # Include lag1 as a regressor
model.add_regressor('lag2')
model.add_regressor('lag3')  # Include lag2 as a regressor
model.add_seasonality(name='monthly', period=30.5, fourier_order=3)  # Monthly seasonality
model.add_seasonality(name='yearly', period=365.25, fourier_order=10)  # Yearly seasonality

# Fit the model
model.fit(prophet_data)

# Make future dataframe (aligned with existing data)
future = prophet_data[['ds', 'lag1','lag2','lag3']]  # Use the same data for predictions

# Generate predictions
forecast = model.predict(future)

# Calculate residuals
prophet_data['yhat'] = forecast['yhat']
prophet_data['residuals'] = prophet_data['y'] - prophet_data['yhat']

# Drop NaN residuals
prophet_data = prophet_data.dropna(subset=['residuals'])

# Calculate metrics
mse = mean_squared_error(prophet_data['y'], prophet_data['yhat'])
mae = mean_absolute_error(prophet_data['y'], prophet_data['yhat'])
mape = np.mean(np.abs((prophet_data['y'] - prophet_data['yhat']) / prophet_data['y'])) * 100

# Sum of Squared Errors (SSE)
sse = np.sum((prophet_data['y'] - prophet_data['yhat']) ** 2)

# Sum of Squares for Regression (SSR)
ssr = np.sum((prophet_data['yhat'] - np.mean(prophet_data['y'])) ** 2)

# Total Sum of Squares (SST)
sst = sse + ssr

# R-Squared (R²)
r2 = ssr / sst

# Adjusted R-Squared
n = len(prophet_data)  # Number of observations
p = 2  # Number of predictors (lag1 and lag2 used in the model)
adjusted_r2 = 1 - ((1 - r2) * (n - 1) / (n - p - 1))

# Print metrics
print(f"Mean Squared Error (MSE): {mse:.2f}")
print(f"Mean Absolute Error (MAE): {mae:.2f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"Sum of Squared Errors (SSE): {sse:.2f}")
print(f"Sum of Squares for Regression (SSR): {ssr:.2f}")
print(f"Total Sum of Squares (SST): {sst:.2f}")
print(f"R-Squared (R²): {r2:.4f}")
print(f"Adjusted R-Squared: {adjusted_r2:.4f}")

# Plot residuals ACF
plot_acf(prophet_data['residuals'], lags=30)
plt.title('ACF of Residuals (Improved Prophet Model)')
plt.show()

# Durbin-Watson Test
dw_stat = durbin_watson(prophet_data['residuals'])
print(f"Durbin-Watson Statistic: {dw_stat:.4f}")

# Forecast plot
fig = model.plot(forecast)
plt.title("Prophet Forecast with Actual Data")
plt.show()


# Components plot
fig2 = model.plot_components(forecast)
plt.savefig('forecast_plot.png')
plt.savefig('residuals_acf.png')
plt.show()
