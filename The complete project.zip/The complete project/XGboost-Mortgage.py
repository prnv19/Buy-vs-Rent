import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('TkAgg')
import tkinter
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score,mean_absolute_error
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.diagnostic import het_white
from statsmodels.regression.linear_model import GLS
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from sklearn.preprocessing import StandardScaler
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.nonparametric.smoothers_lowess import lowess
from scipy.stats import pearsonr
import seaborn as sns
from scipy.stats import boxcox
from statsmodels.stats.anova import anova_lm
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import ElasticNet
from sklearn.feature_selection import RFE
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
from sklearn.decomposition import PCA
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import random

np.random.seed(42)
random.seed(42)
tf.random.set_seed(42)

sales_excel = pd.read_excel("Tables.xlsx")

# Add interaction terms for cities if needed
sales_excel['Denver_TimeIndex'] = sales_excel['RegionName_Denver, CO'] * sales_excel['TimeIndex']
sales_excel['Boulder_HeatIndex'] = sales_excel['RegionName_Boulder, CO'] * sales_excel['HeatIndex']
sales_excel['FortCollins_MortgageRate'] = sales_excel['RegionName_Fort Collins, CO'] * sales_excel['Mortgage rate (30 year)']

# Define features (X) and target (y)
X = sales_excel.drop(columns=['MonthlyMortgagePayment', 'SingleFamilyHomeValueIndex', 'SingleFamilyObservedRentIndex'])
y = sales_excel['MonthlyMortgagePayment']

# Train-test split (No shuffle to preserve time series structure)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Convert to DMatrix (recommended for XGBoost)
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test, label=y_test)

# Define XGBoost parameters
params = {
    'objective': 'reg:squarederror',
    'eval_metric': 'rmse',
    'max_depth': 6,
    'eta': 0.1,
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'seed': 42
}

# Train the model
num_boost_round = 500
early_stopping_rounds = 50
evals = [(dtrain, 'train'), (dtest, 'test')]

model = xgb.train(
    params=params,
    dtrain=dtrain,
    num_boost_round=num_boost_round,
    evals=evals,
    early_stopping_rounds=early_stopping_rounds,
    verbose_eval=10
)

# Predict on test set
y_pred = model.predict(dtest)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Calculate additional metrics
n = len(y_test)  # Number of observations
p = X_train.shape[1]  # Number of predictors

# Sum of Squared Errors (SSE)
sse = np.sum((y_test - y_pred) ** 2)

# Sum of Squares for Regression (SSR)
ssr = np.sum((y_pred - np.mean(y_test)) ** 2)

# Total Sum of Squares (SST)
sst = sse + ssr

# Adjusted R-Squared
adjusted_r2 = 1 - ((1 - r2) * (n - 1) / (n - p - 1))

# Mean Absolute Percentage Error (MAPE)
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

# Print all metrics
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"R-Squared (R2): {r2:.4f}")
print(f"Adjusted R-Squared: {adjusted_r2:.4f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"Sum of Squared Errors (SSE): {sse:.4f}")
print(f"Sum of Squares for Regression (SSR): {ssr:.4f}")
print(f"Total Sum of Squares (SST): {sst:.4f}")

# Feature importance plot
plt.figure(figsize=(10, 8))
xgb.plot_importance(model, importance_type="weight")
plt.title("Feature Importance")
plt.show()

# Visualize a tree
plt.figure(figsize=(20, 15))
xgb.plot_tree(model, num_trees=0, rankdir="LR")
plt.show()


# Predict on test set
y_pred_test = model.predict(dtest)

# Mean Squared Error (MSE) and Mean Absolute Error (MAE)
mse_test = mean_squared_error(y_test, y_pred_test)
mae_test = mean_absolute_error(y_test, y_pred_test)

# R-Squared (R²)
r2_test = r2_score(y_test, y_pred_test)

# Adjusted R-Squared
n_test = X_test.shape[0]  # Number of observations in test set
p_test = X_test.shape[1]  # Number of predictors
adjusted_r2_test = 1 - ((1 - r2_test) * (n_test - 1) / (n_test - p_test - 1))

# Mean Absolute Percentage Error (MAPE)
mape_test = (np.mean(np.abs((y_test - y_pred_test) / y_test)) * 100)

# Sum of Squared Errors (SSE), SSR, and SST
sse_test = np.sum((y_test - y_pred_test) ** 2)
ssr_test = np.sum((y_pred_test - np.mean(y_test)) ** 2)
sst_test = ssr_test + sse_test

# Print the metrics
print(f"Test Data Evaluation:")
print(f"Mean Squared Error (MSE): {mse_test:.4f}")
print(f"Mean Absolute Error (MAE): {mae_test:.4f}")
print(f"R-Squared (R²): {r2_test:.4f}")
print(f"Adjusted R-Squared: {adjusted_r2_test:.4f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape_test:.2f}%")
print(f"Sum of Squared Errors (SSE): {sse_test:.4f}")
print(f"Sum of Squares for Regression (SSR): {ssr_test:.4f}")
print(f"Total Sum of Squares (SST): {sst_test:.4f}")
scaler_X = StandardScaler()
scaler_y = StandardScaler()

X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.values.reshape(-1, 1))

# Prepare data for LSTM
def create_sequences(X, y, time_steps=12):
    X_seq, y_seq = [], []
    for i in range(len(X) - time_steps):
        X_seq.append(X[i:i + time_steps])
        y_seq.append(y[i + time_steps])
    return np.array(X_seq), np.array(y_seq)

time_steps = 12
X_seq, y_seq = create_sequences(X_scaled, y_scaled, time_steps)

# Train-test split
split_ratio = 0.8
split_index = int(len(X_seq) * split_ratio)

X_train, X_test = X_seq[:split_index], X_seq[split_index:]
y_train, y_test = y_seq[:split_index], y_seq[split_index:]

# Build the LSTM model
model = Sequential([
    LSTM(64, activation='tanh', return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
    Dropout(0.2),
    LSTM(32, activation='tanh'),
    Dropout(0.2),
    Dense(1)  # Final output layer
])

model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# Train the model
history = model.fit(
    X_train, y_train,
    validation_data=(X_test, y_test),
    epochs=50,
    batch_size=32,
    verbose=1
)

# Predict on test set
y_pred_scaled = model.predict(X_test)
y_pred = scaler_y.inverse_transform(y_pred_scaled)
y_test_original = scaler_y.inverse_transform(y_test)

# Evaluate the model
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

# Sum of Squared Errors (SSE)
sse = np.sum((y_test - y_pred) ** 2)

# Sum of Squares for Regression (SSR)
ssr = np.sum((y_pred - np.mean(y_test)) ** 2)

# Total Sum of Squares (SST)
sst = sse + ssr

# R-Squared (R²)
r2 = ssr / sst

# Adjusted R-Squared
n = len(y_test)  # Number of observations
p = X_test.shape[1]  # Number of predictors
adjusted_r2 = 1 - ((1 - r2) * (n - 1) / (n - p - 1))

# Print metrics
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"Sum of Squared Errors (SSE): {sse:.4f}")
print(f"Sum of Squares for Regression (SSR): {ssr:.4f}")
print(f"Total Sum of Squares (SST): {sst:.4f}")
print(f"R-Squared (R²): {r2:.4f}")
print(f"Adjusted R-Squared: {adjusted_r2:.4f}")

# Plot training and validation loss
#plt.figure(figsize=(10, 6))
#plt.plot(history.history['loss'], label='Training Loss')
#plt.plot(history.history['val_loss'], label='Validation Loss')
#plt.legend()
#plt.title("Model Loss")
#plt.show()

# Plot predictions vs actual values
#plt.figure(figsize=(10, 6))
#plt.plot(y_test_original, label='Actual')
#plt.plot(y_pred, label='Predicted')
#plt.legend()
#plt.title("Predicted vs Actual Values")
#plt.show()

residuals = y_test - y_pred

# 1. Plot ACF (Autocorrelation Function)
plt.figure(figsize=(10, 6))
plot_acf(residuals, lags=30)  # Adjust lags as needed
plt.title("ACF of Residuals")
plt.show()

# 2. Durbin-Watson Test
dw_stat = durbin_watson(residuals)
print(dw_stat)