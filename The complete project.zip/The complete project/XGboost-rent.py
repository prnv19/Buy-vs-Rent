import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.feature_selection import RFE
from sklearn.linear_model import LinearRegression
import xgboost as xgb

# Set random seed for reproducibility
np.random.seed(42)

# Load your dataset
sales_excel = pd.read_excel("Tables.xlsx")

# Add interaction terms for cities if needed
sales_excel['Denver_TimeIndex'] = sales_excel['RegionName_Denver, CO'] * sales_excel['TimeIndex']
sales_excel['Boulder_HeatIndex'] = sales_excel['RegionName_Boulder, CO'] * sales_excel['HeatIndex']
sales_excel['FortCollins_MortgageRate'] = sales_excel['RegionName_Fort Collins, CO'] * sales_excel['Mortgage rate (30 year)']

# Define features (X) and target (y)
X = sales_excel.drop(columns=['MonthlyMortgagePayment', 'SingleFamilyHomeValueIndex', 'SingleFamilyObservedRentIndex'])
y = sales_excel['SingleFamilyObservedRentIndex']

# Train-test split (No shuffle to preserve time series structure)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Flatten X_train and X_test if 3D
if len(X_train.shape) == 3:
    X_train = X_train.reshape(X_train.shape[0], -1)
    X_test = X_test.reshape(X_test.shape[0], -1)

# Check dimensions
print("Shape of X_train:", X_train.shape)
print("Shape of X_test:", X_test.shape)

# Apply RFE
model = LinearRegression()
selector = RFE(model, n_features_to_select=10)  # Adjust number of features to select
selector.fit(X_train, y_train)

# Get selected features
selected_features = selector.support_
ranking = selector.ranking_
print("Selected Features (Boolean Mask):", selected_features)
print("Feature Ranking:", ranking)

# Filter selected features in the dataset (convert to a list of column names)
selected_feature_names = X_train.columns[selected_features]
print("Selected Feature Names:", selected_feature_names)

# Use the column names to subset the DataFrame
X_train_selected = X_train[selected_feature_names]
X_test_selected = X_test[selected_feature_names]

# Check dimensions
print("Shape of X_train_selected:", X_train_selected.shape)
print("Shape of X_test_selected:", X_test_selected.shape)

# Train XGBoost Model
dtrain = xgb.DMatrix(X_train_selected, label=y_train)
dtest = xgb.DMatrix(X_test_selected, label=y_test)

# Define XGBoost parameters
params = {
    'objective': 'reg:squarederror',
    'eval_metric': 'rmse',
    'max_depth': 6,
    'eta': 0.1,
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'seed': 42
}

# Train the model
num_boost_round = 500
early_stopping_rounds = 50
evals = [(dtrain, 'train'), (dtest, 'test')]

model = xgb.train(
    params=params,
    dtrain=dtrain,
    num_boost_round=num_boost_round,
    evals=evals,
    early_stopping_rounds=early_stopping_rounds,
    verbose_eval=10
)

# Predict on test set
y_pred = model.predict(dtest)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Calculate additional metrics
n = len(y_test)  # Number of observations
p = X_train_selected.shape[1]  # Number of predictors

# Sum of Squared Errors (SSE)
sse = np.sum((y_test - y_pred) ** 2)

# Sum of Squares for Regression (SSR)
ssr = np.sum((y_pred - np.mean(y_test)) ** 2)

# Total Sum of Squares (SST)
sst = sse + ssr

# Adjusted R-Squared
adjusted_r2 = 1 - ((1 - r2) * (n - 1) / (n - p - 1))

# Mean Absolute Percentage Error (MAPE)
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

# Print all metrics
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"R-Squared (R2): {r2:.4f}")
print(f"Adjusted R-Squared: {adjusted_r2:.4f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"Sum of Squared Errors (SSE): {sse:.4f}")
print(f"Sum of Squares for Regression (SSR): {ssr:.4f}")
print(f"Total Sum of Squares (SST): {sst:.4f}")

# Feature importance plot
plt.figure(figsize=(10, 8))
xgb.plot_importance(model, importance_type="weight")
plt.title("Feature Importance")
plt.show()

# Visualize a tree
plt.figure(figsize=(20, 15))
xgb.plot_tree(model, num_trees=0, rankdir="LR")
plt.show()

original_features = X_train.columns

# Get the selected feature names
selected_features = X_train.columns[selected_features]

# Find the removed predictors
removed_features = original_features.difference(selected_features)

print("Original Features:")
print(original_features.tolist())

print("\nSelected Features (Retained):")
print(selected_features.tolist())

print("\nRemoved Features (Deleted):")
print(removed_features.tolist())