import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('TkAgg')
import tkinter
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score,mean_absolute_error
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.diagnostic import het_white
from statsmodels.regression.linear_model import GLS
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from sklearn.preprocessing import StandardScaler
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.nonparametric.smoothers_lowess import lowess
from scipy.stats import pearsonr
import seaborn as sns
from scipy.stats import boxcox
from statsmodels.stats.anova import anova_lm
from sklearn.preprocessing import PolynomialFeatures
from pmdarima import auto_arima

#Reading All the CSV Files 
mortgage_CSV = pd.read_csv("30yearAvgMortgageRate.csv")
heat_index_csv = pd.read_csv("Monthly Heat index.csv")
consumer_price_index_csv = pd.read_csv("Consumer Price Index for All Urban Consumers (CPI-U)(Sheet1).csv")
consumer_sentiment_index = pd.read_csv("ConsumerSentimentIndex.csv")
numberOf_listing_colorado_csv = pd.read_csv("the_count_of_unique_listing_for_sale.csv")
inflation_expectation_csv =pd.read_csv("inflation_expectation.csv")
average_hourly_earning_csv = pd.read_csv("Average Hourly Earnings of All Employees Total Private in Colorado.csv")
labor_participation_csv = pd.read_csv("Labor Force Participation Rate for Colorado.csv")
personal_saving_rate_csv = pd.read_csv("personal saving rate.csv")
single_family_home_Value_index = pd.read_csv("Single_family_metro_Home_value_index.csv")
single_rent_home_value_index = pd.read_csv("Single_family_metro_Obeserved_rent_index.csv")
colorado_unemployment = pd.read_csv("Colorado_unemployment.csv")
new_privte_housing_permit_colorado = pd.read_csv("New Private Housing Units Authorized by Building Permits 1-Unit Structures for Colorado.csv")



#cleaning and nameing
#formatting according to time
# melting 
#merging

mortgage_CSV["Mortgage rate (30 year)"] = pd.to_numeric(mortgage_CSV["MORTGAGE30US"], errors='coerce')
mortgage_CSV['DATE'] = pd.to_datetime(mortgage_CSV['DATE'], errors = 'coerce') + pd.offsets.MonthEnd(-1)
mortgage_CSV.drop(columns=["MORTGAGE30US"],inplace=True)
mortgage_CSV = mortgage_CSV.iloc[6:]

heat_index_csv = heat_index_csv[heat_index_csv["StateName"] == 'CO']
heat_index_csv.drop(columns=["RegionID","SizeRank","RegionType","StateName"], inplace=True, errors='raise')
heat_index_csv = heat_index_csv.drop(heat_index_csv.loc[:, "1/31/2018":"7/31/2018"].columns, axis=1)
heat_index_csv = heat_index_csv.iloc[:, :-2]

consumer_price_index_csv = consumer_price_index_csv.iloc[:,:2]
consumer_price_index_csv['DATE'] = pd.to_datetime(consumer_price_index_csv['DATE'], errors = 'coerce') + pd.offsets.MonthEnd(-1)
consumer_price_index_csv['CPI-U'] = pd.to_numeric(consumer_price_index_csv['CPI-U'], errors='coerce')
consumer_price_index_csv["Monthly Inflation"] = consumer_price_index_csv['CPI-U'].pct_change() * 100
consumer_price_index_csv =consumer_price_index_csv.dropna()
consumer_price_index_csv.drop(columns=["CPI-U"], inplace=True, errors='raise')
consumer_price_index_csv = consumer_price_index_csv.iloc[4:]
consumer_price_index_csv = consumer_price_index_csv.iloc[:-1]

consumer_sentiment_index["Consumer Sentiment Index"] = pd.to_numeric(consumer_sentiment_index["UMCSENT"], errors='coerce')
consumer_sentiment_index['DATE'] = pd.to_datetime(consumer_sentiment_index['DATE'], errors='coerce') + pd.offsets.MonthEnd(-1)
consumer_sentiment_index.drop(columns=["UMCSENT"], inplace=True, errors='raise')
consumer_sentiment_index = consumer_sentiment_index.iloc[5:]

numberOf_listing_colorado_csv = numberOf_listing_colorado_csv[numberOf_listing_colorado_csv["StateName"] == 'CO']
numberOf_listing_colorado_csv.drop(columns=["RegionID","SizeRank","RegionType","StateName"], inplace=True, errors='raise')
numberOf_listing_colorado_csv = numberOf_listing_colorado_csv.iloc[:, :-2]
numberOf_listing_colorado_csv = numberOf_listing_colorado_csv.drop(numberOf_listing_colorado_csv.loc[:, "3/31/2018":"7/31/2018"].columns, axis=1)

inflation_expectation_csv['DATE'] = pd.to_datetime(inflation_expectation_csv['DATE'], errors='coerce') + pd.offsets.MonthEnd(-1)
inflation_expectation_csv['Inflation Expectation Rate'] = pd.to_numeric(inflation_expectation_csv["MICH"], errors='coerce')
inflation_expectation_csv.drop(columns=["MICH"], inplace=True, errors='raise')
inflation_expectation_csv = inflation_expectation_csv.iloc[5:]

average_hourly_earning_csv['DATE'] = pd.to_datetime(average_hourly_earning_csv['DATE'], errors='coerce') + pd.offsets.MonthEnd(-1)
average_hourly_earning_csv["Average Hourly Earning"] = pd.to_numeric(average_hourly_earning_csv["SMU08000000500000003"], errors='coerce')
average_hourly_earning_csv.drop(columns=["SMU08000000500000003"], inplace=True, errors='raise')
average_hourly_earning_csv = average_hourly_earning_csv.iloc[5:]

labor_participation_csv['DATE'] = pd.to_datetime(labor_participation_csv['DATE'], errors='coerce') + pd.offsets.MonthEnd(-1)
labor_participation_csv['Labor Participation Rate'] = pd.to_numeric(labor_participation_csv["LBSNSA08"], errors='coerce')
labor_participation_csv.drop(columns=["LBSNSA08"], inplace=True,errors='raise')

personal_saving_rate_csv['DATE'] = pd.to_datetime(personal_saving_rate_csv['DATE'],errors='coerce') + pd.offsets.MonthEnd(-1) 
personal_saving_rate_csv['Personal Saving Rate'] = pd.to_numeric(personal_saving_rate_csv["PSAVERT"], errors='coerce')
personal_saving_rate_csv.drop(columns=["PSAVERT"], inplace=True ,errors='raise')
personal_saving_rate_csv = personal_saving_rate_csv.iloc[5:]

single_family_home_Value_index = single_family_home_Value_index[single_family_home_Value_index["StateName"] == 'CO']
single_family_home_Value_index.drop(columns=["RegionID","SizeRank","RegionType","StateName"], inplace=True, errors='raise')
single_family_home_Value_index = single_family_home_Value_index.drop(single_family_home_Value_index.loc[:, "1/31/2000":"7/31/2018"].columns, axis=1)
single_family_home_Value_index = single_family_home_Value_index.iloc[:, :-2]

single_rent_home_value_index = single_rent_home_value_index[single_rent_home_value_index["StateName"] == 'CO']
single_rent_home_value_index.drop(columns=["RegionID","SizeRank","RegionType","StateName"], inplace=True, errors='raise')
single_rent_home_value_index  = single_rent_home_value_index.drop(single_rent_home_value_index.loc[:, "1/31/2015":"7/31/2018"].columns, axis=1)
single_rent_home_value_index = single_rent_home_value_index.iloc[:, :-2]

colorado_unemployment["DATE"] = pd.to_datetime(colorado_unemployment["DATE"], errors='coerce') + pd.offsets.MonthEnd(-1)
colorado_unemployment["Unemployment Rate"] = pd.to_numeric(colorado_unemployment['COURN'] , errors='coerce')
colorado_unemployment.drop(columns=["COURN"], inplace=True, errors='raise')
colorado_unemployment = colorado_unemployment.iloc[5:]

new_privte_housing_permit_colorado['DATE'] = pd.to_datetime(new_privte_housing_permit_colorado['DATE'], errors='coerce') + pd.offsets.MonthEnd(-1)
new_privte_housing_permit_colorado['Number of permits Authorized'] = pd.to_numeric(new_privte_housing_permit_colorado["COBP1FHSA"], errors='coerce')
new_privte_housing_permit_colorado.drop(columns=["COBP1FHSA"], inplace=True, errors='coerce')
new_privte_housing_permit_colorado = new_privte_housing_permit_colorado.iloc[5:]

single_family_home_Value_index = single_family_home_Value_index[~single_family_home_Value_index["RegionName"].isin([
    'Edwards, CO', 'Durango, CO', 'Montrose, CO', 'Breckenridge, CO', 'Steamboat Springs, CO', 'Ca-¦on City, CO','Craig, CO','Sterling, CO','Fort Morgan, CO','Glenwood Springs, CO',
'Pueblo, CO','Greeley, CO','Grand Junction, CO','Colorado Springs, CO'])]

single_rent_home_value_index = single_rent_home_value_index[~single_rent_home_value_index["RegionName"].isin([
    'Edwards, CO', 'Durango, CO', 'Montrose, CO', 'Breckenridge, CO', 'Steamboat Springs, CO', 'Ca-¦on City, CO','Craig, CO','Sterling, CO','Fort Morgan, CO','Glenwood Springs, CO',
'Pueblo, CO','Greeley, CO','Grand Junction, CO','Colorado Springs, CO'])]

numberOf_listing_colorado_csv = numberOf_listing_colorado_csv[~numberOf_listing_colorado_csv["RegionName"].isin([
    'Edwards, CO', 'Durango, CO', 'Montrose, CO', 'Breckenridge, CO', 'Steamboat Springs, CO', 'Ca-¦on City, CO','Craig, CO','Sterling, CO','Fort Morgan, CO','Glenwood Springs, CO',
'Pueblo, CO','Greeley, CO','Grand Junction, CO','Colorado Springs, CO'])]

heat_index_csv = heat_index_csv[~heat_index_csv["RegionName"].isin([
    'Edwards, CO', 'Durango, CO', 'Montrose, CO', 'Breckenridge, CO', 'Steamboat Springs, CO', 'Ca-¦on City, CO','Craig, CO','Sterling, CO','Fort Morgan, CO','Glenwood Springs, CO',
'Pueblo, CO','Greeley, CO','Grand Junction, CO','Colorado Springs, CO'])]

def monthly_mortgage_calculator(home_value_index, mortgage_rate, term_year=30, down_payment_percent = 0.2):
    monthlyRate = (mortgage_rate/100)/ 12
    down_payment = home_value_index * down_payment_percent
    principal = home_value_index - down_payment
    total_payments = term_year * 12
    monthly_payment = principal * (monthlyRate * (1 + monthlyRate)**total_payments) / \
                                   ((1 + monthlyRate)**(total_payments) - 1)
    return monthly_payment
 


single_family_home_Value_index_long = single_family_home_Value_index.melt(id_vars="RegionName", var_name="Time", value_name = "SingleFamilyHomeValueIndex")
single_rent_home_value_index_long = single_rent_home_value_index.melt(id_vars="RegionName", var_name="Time", value_name = "SingleFamilyObservedRentIndex")
numberOf_listing_colorado_csv_long = numberOf_listing_colorado_csv.melt(id_vars="RegionName", var_name="Time", value_name = "NumberOfListings")
heat_index_csv_long = heat_index_csv.melt(id_vars="RegionName", var_name="Time", value_name="HeatIndex")

zillow_combined_long = pd.merge(single_family_home_Value_index_long,single_rent_home_value_index_long, on=["RegionName","Time"], how="inner")
zillow_combined_long = pd.merge(zillow_combined_long,numberOf_listing_colorado_csv_long, on=["RegionName","Time"], how="inner")
zillow_combined_long = pd.merge(zillow_combined_long,heat_index_csv_long, on=["RegionName","Time"], how="inner")


economic_df = pd.merge(mortgage_CSV,consumer_price_index_csv, on="DATE",how="inner")
economic_df = pd.merge(economic_df,consumer_sentiment_index, on="DATE",how="inner")
economic_df = pd.merge(economic_df,inflation_expectation_csv, on="DATE",how="inner")
economic_df = pd.merge(economic_df,average_hourly_earning_csv, on="DATE",how="inner")
economic_df = pd.merge(economic_df,labor_participation_csv, on="DATE",how="inner")
economic_df = pd.merge(economic_df,personal_saving_rate_csv, on="DATE",how="inner")
economic_df = pd.merge(economic_df,colorado_unemployment, on="DATE",how="inner")
economic_df = pd.merge(economic_df,new_privte_housing_permit_colorado, on="DATE",how="inner")

#test_column = economic_df[["Unemployment Rate",'Personal Saving Rate']]
#coorelation_matrix = economic_df.corr()
#print(coorelation_matrix)

#sns.heatmap(coorelation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
#plt.title("Correlation Matrix Heatmap")
#plt.show()

zillow_combined_long.rename(columns={"Time":"DATE"}, inplace=True)


zillow_combined_long["DATE"] = pd.to_datetime(zillow_combined_long["DATE"], errors="coerce")
economic_df.set_index("DATE",inplace=True)
zillow_combined_long.set_index("DATE", inplace=True)

economic_df["TimeIndex"] = (economic_df.index.year - economic_df.index.year.min()) * 12 + economic_df.index.month
zillow_combined_long["TimeIndex"] = (zillow_combined_long.index.year - zillow_combined_long.index.year.min()) * 12 + zillow_combined_long.index.month
final_Df_rent = pd.merge(zillow_combined_long,economic_df, on="TimeIndex", how="left")

final_Df_rent["MonthlyMortgagePayment"] = final_Df_rent.apply(lambda row: monthly_mortgage_calculator(home_value_index=row["SingleFamilyHomeValueIndex"], mortgage_rate=row["Mortgage rate (30 year)"]), axis=1)

final_Df_rent = pd.get_dummies(final_Df_rent, columns=["RegionName"], drop_first=False)

final_Df_rent.to_excel("Rent.xlsx", index=None)








#print(final_Df.columns)
#final_Df.to_excel("Tables.xlsx", index=None)
X_Rent = final_Df_rent.drop(columns=['SingleFamilyHomeValueIndex','SingleFamilyObservedRentIndex','MonthlyMortgagePayment'])
Y_Rent = final_Df_rent['SingleFamilyObservedRentIndex']
Y_Rent = np.log(final_Df_rent['SingleFamilyObservedRentIndex'])
rentScaler = StandardScaler()
X_rent_scaled = rentScaler.fit_transform(X_Rent)
X_Rent['Lag1'] = Y_Rent.shift(1)  # Add Lag 1
X_Rent['Lag2'] = Y_Rent.shift(2)
X_Rent = X_Rent.dropna()
Y_Rent = Y_Rent.loc[X_Rent.index]

x_rent_train, x_rent_test, y_rent_train, y_rent_test = train_test_split(X_Rent,Y_Rent, test_size=0.2, shuffle=False)
RentModel = LinearRegression()
x_rent_train = x_rent_train.astype({col: 'int32' for col in x_rent_train.select_dtypes(include=['bool']).columns})
x_rent_test = x_rent_test.astype({col: 'int32' for col in x_rent_test.select_dtypes(include=['bool']).columns})
RentModel.fit(x_rent_train,y_rent_train)

y_rent_predict_test = RentModel.predict(x_rent_test)
y_rent_predict_train = RentModel.predict(x_rent_train)

poly = PolynomialFeatures(degree=2, include_bias=False)
X_rent_poly_train = poly.fit_transform(x_rent_train)
X_rent_poly_test = poly.fit_transform(x_rent_test)
RentModel.fit(X_rent_poly_train, y_rent_train)
y_polyrent_predict_train = RentModel.predict(X_rent_poly_train)


#Evaluation of Sales 
rent_train_mse = mean_squared_error(y_rent_train,y_polyrent_predict_train).round(4)
rent_train_r2 = r2_score(y_rent_train,y_polyrent_predict_train).round(4)
rent_train_mae = mean_absolute_error(y_rent_train, y_polyrent_predict_train).round(4)
rent_train_mape = (np.mean(np.abs((y_rent_train - y_polyrent_predict_train) / np.where(y_rent_train != 0, y_rent_train, np.nan))) * 100).round(4)
rent_train_n = X_rent_poly_train.shape[0]
rent__train_p = X_rent_poly_train.shape[1]
rent_train_SSE = np.sum((y_rent_train - y_polyrent_predict_train) ** 2).round(4)
rent_train_SSR = np.sum((y_polyrent_predict_train - np.mean(y_rent_train)) ** 2).round(4)
adjusted_R2_train_rent = (1 - ((1-rent_train_r2) * (rent_train_n -1)) / (rent_train_n - rent__train_p -1)).round(4)
rent_train_SST = rent_train_SSR + rent_train_SSE

print(f"Sum of Squared Errors (SSE) Rent (train): {rent_train_SSE}")
print(f"Sum of Squares for Regression (SSR) Rent (train): {rent_train_SSR}")
print(f"Total Sum of Squares (SST) Rent (train): {rent_train_SST}")
print(f"Mean Squered Error (MSE) Rent (train): {rent_train_mse}")
print(f"R-Squered (R^2) Rent (train): {rent_train_r2}")
print(f"Adjusted R-Squared Rent (train): {adjusted_R2_train_rent}")
print(f"Mean Absolute Error (MAE) Rent (train): {rent_train_mae}")
print(f"Mean Absolute Percentage Error (MAPE) Rent (train): {rent_train_mape}%")
print(rent_train_r2-adjusted_R2_train_rent)






predictors = x_rent_train.columns

# Predicted Rent vs Predictors
#for p in predictors:
#    loess_smoothed_predicted = lowess(y_rent_predict_train, x_rent_train[p], frac=0.3)
#    plt.figure(figsize=(10, 6))
#    plt.scatter(x_rent_train[p], y_rent_predict_train, alpha=0.5, color='blue', label="Predicted Rent")
#    plt.plot(loess_smoothed_predicted[:, 0], loess_smoothed_predicted[:, 1], 
#             color="red", label="LOESS Line")
#    plt.xlabel(f"{p}")
#    plt.ylabel("Predicted Rent")
#    plt.title(f"Predicted Rent vs {p}. train")
#    plt.legend()
#    plt.show()

# Residuals vs Predictors
rent_train_Residual = y_rent_train - y_polyrent_predict_train
#for p in predictors:
#    loess_smoothed_residual = lowess(rent_train_Residual, x_rent_train[p], frac=0.3)
#    plt.figure(figsize=(10, 6))
#    plt.scatter(x_rent_train[p], rent_train_Residual, alpha=0.5, color='blue', label="Residuals")
#    plt.plot(loess_smoothed_residual[:, 0], loess_smoothed_residual[:, 1], 
#             color="red", label="LOESS Line")
#    plt.axhline(0, color="lightblue", linestyle='--', label="Zero Line")
#    plt.xlabel(f"{p}")
#    plt.ylabel("Residual")
#    plt.title(f"Residual vs {p} Rent (train)")
#    plt.legend()
#    plt.show()


#Residual VSFitted 
#plt.figure(figsize=(10,6))
#loess_smoothed_residual = lowess(rent_train_Residual, y_polyrent_predict_train, frac=0.3)
#plt.scatter(y_polyrent_predict_train,rent_train_Residual , alpha=0.5, color='blue', label="Residual Vs Fitted Values")
#plt.plot(loess_smoothed_residual[:, 0], loess_smoothed_residual[:, 1], 
#             color="red", label="LOESS Line")
#plt.axhline(0, color='red', linestyle='--')
#plt.xlabel("Fitted Values (Rent)")
#plt.ylabel("Residuals")
#plt.title("Residuals vs Fitted Rent Values (Train Set)")
#plt.show()


#plt.figure(figsize=(10, 6))
#loess_smoothed_residual = lowess(poly_sales_train_residual, y_sales_predict_train_poly, frac=0.3)
#plt.scatter(y_sales_predict_train_poly, poly_sales_train_residual, alpha=0.5, color='blue')
#plt.plot(loess_smoothed_residual[:, 0], loess_smoothed_residual[:, 1], 
#             color="red", label="LOESS Line")
#plt.axhline(0, color='red', linestyle='--')
#plt.xlabel("Polynomial Fitted Values (Predicted Mortgage)")
#plt.ylabel("Residuals")
#plt.title("Residuals vs Poylnomial Fitted Values (Train Set)")
#plt.show()



# Actual vs Predicted Rent
#plt.figure(figsize=(10, 6))
#plt.scatter(y_rent_train, y_polyrent_predict_train, alpha=0.5, color='blue', label="Predicted vs Actual")
#plt.plot([min(y_rent_train), max(y_rent_train)], [min(y_rent_train), max(y_rent_train)], 
#         color='red', linestyle='--', label="Perfect Fit")
#plt.xlabel("Actual Rent")
#plt.ylabel("Fitted Rent")
#plt.title("Actual Rent vs Fitted Rent (train)")
#plt.legend()
#plt.show()



#sm.qqplot(rent_train_Residual, line='s')
#plt.title("Q-Q Plot of Residuals Rent (Train Set)")
#plt.show()

# Calculate standardized residuals
#standardized_residuals = rent_train_Residual / np.std(rent_train_Residual)
#sqrt_standardized_residuals = np.sqrt(np.abs(standardized_residuals))

# Scale-Location Plot
#plt.figure(figsize=(10, 6))
#plt.scatter(y_polyrent_predict_train, sqrt_standardized_residuals, alpha=0.5, color='blue', label="Residuals")
#loess_smoothed_scale_location = lowess(sqrt_standardized_residuals, y_polyrent_predict_train, frac=0.3)
#plt.plot(loess_smoothed_scale_location[:, 0], loess_smoothed_scale_location[:, 1], color="red", label="LOESS Line")
#plt.axhline(0, color="lightblue", linestyle="--")
#plt.xlabel("Fitted Values (Predicted Rent)")
#plt.ylabel("√|Standardized Residuals|")
#plt.title("Scale-Location Plot Rent (Train Set)")
#plt.legend()
#plt.show()

# Residuals vs Leverage Plot
model_with_stats = sm.OLS(y_rent_train, sm.add_constant(x_rent_train)).fit()
influence = model_with_stats.get_influence()
leverage = influence.hat_matrix_diag
studentized_residuals = influence.resid_studentized_external

#plt.figure(figsize=(10, 6))
#plt.scatter(leverage, studentized_residuals, alpha=0.5, color='blue', label="Studentized Residuals")
#plt.axhline(0, color='red', linestyle='--', label="Zero Line")
#plt.xlabel("Leverage")
#plt.ylabel("Studentized Residuals")
#plt.title("Residuals vs Leverage Plot Rent (Train Set)")
#plt.legend()
#plt.show()

# Adding Cook's Distance to the Residuals vs Leverage Plot
cooks_d = influence.cooks_distance[0]

#plt.figure(figsize=(10, 6))
#plt.scatter(leverage, studentized_residuals, alpha=0.5, color='blue', label="Studentized Residuals")
#plt.axhline(0, color='red', linestyle='--', label="Zero Line")
#plt.scatter(leverage, studentized_residuals, c=cooks_d, cmap='coolwarm', label="Cook's Distance", edgecolor='k')
#plt.colorbar(label="Cook's Distance")
#plt.xlabel("Leverage")
#plt.ylabel("Studentized Residuals")
#plt.title("Residuals vs Leverage Plot Rent (Train Set) with Cook's Distance")
#plt.legend()
#plt.show()

#bp_test = het_breuschpagan(rent_train_Residual, sm.add_constant(X_rent_poly_train))
#print(f"Breusch-Pagan test p-value: {bp_test[1]}")

#dw_stat = durbin_watson(rent_train_Residual)
#print(f"Durbin-Watson statistic: {dw_stat}")

#plt.figure(figsize=(10, 6))
#plot_acf(rent_train_Residual, lags=40)
#plt.title("Autocorrelation Function (ACF) for Residuals")
#plt.xlabel("Lags")
#plt.ylabel("Autocorrelation")
#plt.show()

#plt.figure(figsize=(10, 6))
#plot_pacf(rent_train_Residual, lags=40)
#plt.title("Partial Autocorrelation Function (PACF) for Residuals")
#plt.xlabel("Lags")
#plt.ylabel("Partial Autocorrelation")
#plt.show()


from sklearn.linear_model import ElasticNet
from sklearn.model_selection import GridSearchCV

# Define the parameter grid for Elastic Net
param_grid = {
    'alpha': [0.1, 1.0, 10.0],  # Regularization strength
    'l1_ratio': [0.2, 0.5, 0.8]  # Balance between L1 and L2 penalties
}

# Initialize ElasticNet and GridSearchCV
elastic_net = ElasticNet(max_iter=10000)
grid_search = GridSearchCV(estimator=elastic_net, param_grid=param_grid, cv=5, scoring='neg_mean_squared_error')

# Fit the model on training data
grid_search.fit(X_rent_poly_train, y_rent_train)

# Get the best model
best_elastic_net = grid_search.best_estimator_

# Predict on training and testing data
y_rent_predict_train_en = best_elastic_net.predict(X_rent_poly_train)
y_rent_predict_test_en = best_elastic_net.predict(X_rent_poly_test)

# Evaluate the ElasticNet model
en_train_mse = mean_squared_error(y_rent_train, y_rent_predict_train_en).round(4)
en_train_r2 = r2_score(y_rent_train, y_rent_predict_train_en).round(4)
en_train_mae = mean_absolute_error(y_rent_train, y_rent_predict_train_en).round(4)

print("ElasticNet Model Performance:")
print(f"Train MSE: {en_train_mse}")
print(f"Train R²: {en_train_r2}")
print(f"Train MAE: {en_train_mae}")
print(f"Best Parameters: {grid_search.best_params_}")

# Residual Analysis
residuals_en = y_rent_train - y_rent_predict_train_en

# Residual Diagnostics
plt.figure(figsize=(10, 6))
plt.scatter(y_rent_predict_train_en, residuals_en, alpha=0.5, color='blue')
plt.axhline(0, color='red', linestyle='--', label="Zero Line")
plt.title("Residuals vs Fitted Values (ElasticNet)")
plt.xlabel("Fitted Values")
plt.ylabel("Residuals")
plt.legend()
plt.show()

# Q-Q Plot for Residuals
sm.qqplot(residuals_en, line='s')
plt.title("Q-Q Plot of Residuals (ElasticNet)")
plt.show()

# ACF and PACF for Residuals
plt.figure(figsize=(10, 6))
plot_acf(residuals_en, lags=40)
plt.title("Autocorrelation Function (ACF) for Residuals (ElasticNet)")
plt.xlabel("Lags")
plt.ylabel("Autocorrelation")
plt.show()

plt.figure(figsize=(10, 6))
plot_pacf(residuals_en, lags=40)
plt.title("Partial Autocorrelation Function (PACF) for Residuals (ElasticNet)")
plt.xlabel("Lags")
plt.ylabel("Partial Autocorrelation")
plt.show()


# Calculate metrics for Train data
sse_train = np.sum((y_rent_train - y_rent_predict_train_en)**2).round(4)
sst_train = np.sum((y_rent_train - np.mean(y_rent_train))**2).round(4)
ssr_train = sst_train - sse_train
mape_train = (np.mean(np.abs((y_rent_train - y_rent_predict_train_en) / y_rent_train)) * 100).round(4)
adjusted_r2_train = (1 - ((1 - en_train_r2) * (len(y_rent_train) - 1)) / (len(y_rent_train) - x_rent_train.shape[1] - 1)).round(4)

# Calculate metrics for Test data
sse_test = np.sum((y_rent_test - y_rent_predict_test_en)**2).round(4)
sst_test = np.sum((y_rent_test - np.mean(y_rent_test))**2).round(4)
ssr_test = sst_test - sse_test
mape_test = (np.mean(np.abs((y_rent_test - y_rent_predict_test_en) / y_rent_test)) * 100).round(4)
r2_test = r2_score(y_rent_test, y_rent_predict_test_en).round(4)
adjusted_r2_test = (1 - ((1 - r2_test) * (len(y_rent_test) - 1)) / (len(y_rent_test) - x_rent_test.shape[1] - 1)).round(4)

# Display the results
print("ElasticNet Model Metrics:")
print("Train Metrics:")
print(f"Sum of Squared Errors (SSE) Train: {sse_train}")
print(f"Sum of Squares for Regression (SSR) Train: {ssr_train}")
print(f"Total Sum of Squares (SST) Train: {sst_train}")
print(f"R-Squared (R^2) Train: {en_train_r2}")
print(f"Adjusted R-Squared Train: {adjusted_r2_train}")
print(f"Mean Absolute Percentage Error (MAPE) Train: {mape_train}%")

print("\nTest Metrics:")
print(f"Sum of Squared Errors (SSE) Test: {sse_test}")
print(f"Sum of Squares for Regression (SSR) Test: {ssr_test}")
print(f"Total Sum of Squares (SST) Test: {sst_test}")
print(f"R-Squared (R^2) Test: {r2_test}")
print(f"Adjusted R-Squared Test: {adjusted_r2_test}")
print(f"Mean Absolute Percentage Error (MAPE) Test: {mape_test}%")

from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller

# Check stationarity using ADF test
series = y_rent_train

# Check stationarity of the target variable
print("Performing ADF Test on Transformed Response...")
series_diff = series.diff().dropna()
adf_result = adfuller(series_diff)

print("ADF Statistic:", adf_result[0])
print("p-value:", adf_result[1])

if adf_result[1] > 0.05:
    print("Series is non-stationary. Applying first differencing.")
    series_diff = series.diff().dropna()
else:
    print("Series is stationary.")
    series_diff = series

# Plot ACF and PACF to determine ARIMA parameters (p, d, q)
#print("Plotting ACF and PACF for ARIMA...")
#fig, ax = plt.subplots(1, 2, figsize=(12, 5))
#plot_acf(series_diff, lags=40, ax=ax[0])
#plot_pacf(series_diff, lags=40, ax=ax[1])
#plt.show()

# Set ARIMA parameters based on ACF and PACF analysis
p, d, q = 1, 1, 1  # Adjust based on the plots

# Fit ARIMA model
print(f"Fitting ARIMA({p}, {d}, {q}) model on transformed response...")
arima_model = ARIMA(series, order=(p, d, q))
arima_result = arima_model.fit()

# Model Summary
print(arima_result.summary())

# Plot ARIMA Fitted Values against the Transformed Series
plt.figure(figsize=(10, 6))
plt.plot(series, label="Original Transformed Response")
plt.plot(arima_result.fittedvalues, label="Fitted Values (ARIMA)", color="red")
plt.legend()
plt.title("ARIMA Fitted Values for Transformed Response")
plt.show()

# Forecast Future Values
forecast_steps = 12  # Predict next 12 months
forecast = arima_result.get_forecast(steps=forecast_steps)
forecast_mean = forecast.predicted_mean
forecast_ci = forecast.conf_int()

# Plot Forecast
plt.figure(figsize=(10, 6))
plt.plot(series, label="Original Transformed Response")
plt.plot(forecast_mean, label="Forecast", color="green")
plt.fill_between(forecast_ci.index, 
                 forecast_ci.iloc[:, 0], 
                 forecast_ci.iloc[:, 1], 
                 color='lightgreen', alpha=0.3)
plt.legend()
plt.title("ARIMA Forecast with Confidence Intervals")
plt.show()